//
//  common.h
//  SRI
//
//  Created by Babbie Monahelis on 3/9/17.
//  Copyright � 2017 Babbie Monahelis. All rights reserved.
//


#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <sstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <map>
#include <unordered_map>
#include <thread>
#include <mutex>
#include <future>
using namespace std;